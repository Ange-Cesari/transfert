#!/bin/bash
set -euo pipefail

### === VARIABLES (à éditer ici si besoin) === ###
TENANT=""
WORKSPACE=""
DN=""

### === VÉRIFICATION DES VARIABLES === ###
[[ -z "$WORKSPACE" ]] && read -rp "Entrez le workspace (ex: dev): " WORKSPACE
[[ -z "$TENANT" ]] && read -rp "Entrez le tenant (ex: nova): " TENANT
[[ -z "$DN" ]] && read -rp "Entrez le DN (ex: infra.local): " DN

NEXUS_URL="https://nexus.${WORKSPACE}.${TENANT}.${DN}"

### === CONFIGURATION === ###
AUTH_HEADER="Authorization: Basic ${NEXUS_AUTH_B64:-}"
INSECURE="--insecure"  # Pour certificats TLS autosignés

FIRST_NAME="CI"
LAST_NAME="Service"
EMAIL_DOMAIN="noreply.local"
STATUS="active"

generate_password() {
    tr -dc 'A-Za-z0-9!@#%+=-' </dev/urandom | head -c 20
}

usage() {
    echo "Usage: $0 --username <user_id>"
    exit 1
}

USERNAME=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --username)
            USERNAME="$2"
            shift 2
            ;;
        *)
            echo "Option inconnue: $1"
            usage
            ;;
    esac
done

[[ -z "$USERNAME" ]] && usage

PASSWORD="$(generate_password)"
EMAIL="${USERNAME}@${EMAIL_DOMAIN}"

echo "🛠️  Création de l'utilisateur '$USERNAME' sur $NEXUS_URL..."

curl -sS $INSECURE -X POST "$NEXUS_URL/service/rest/v1/security/users" \
    -H "$AUTH_HEADER" \
    -H "Content-Type: application/json" \
    -d @- <<EOF
{
  "userId": "${USERNAME}",
  "firstName": "${FIRST_NAME}",
  "lastName": "${LAST_NAME}",
  "emailAddress": "${EMAIL}",
  "password": "${PASSWORD}",
  "status": "${STATUS}",
  "roles": []
}
EOF

echo "✅ Utilisateur créé."

echo "🔐 Récupération du user token..."

B64_USER=$(echo -n "$USERNAME:$PASSWORD" | base64)

TOKEN_RESPONSE=$(curl -sS $INSECURE -X GET "$NEXUS_URL/service/rest/v1/security/usertoken" \
    -H "Authorization: Basic $B64_USER" \
    -H "Accept: application/json")

USER_TOKEN=$(echo "$TOKEN_RESPONSE" | jq -r '.token.userToken')
PASS_TOKEN=$(echo "$TOKEN_RESPONSE" | jq -r '.token.passToken')
ENCODED_TOKEN=$(echo -n "$USER_TOKEN:$PASS_TOKEN" | base64)

echo
echo "🎉 Compte de service créé avec succès !"
echo "--------------------------------------"
echo "👤 Username        : $USERNAME"
echo "🔑 Password        : $PASSWORD"
echo "🔐 UserToken       : $USER_TOKEN"
echo "🗝️  PassToken       : $PASS_TOKEN"
echo "📦 Base64 (auth)   : $ENCODED_TOKEN"
echo "--------------------------------------"
