# 🛠️ NAC – Nexus Account Creator

`nac.sh` est un script Bash pour automatiser la création d’un **compte de service** dans **Nexus Repository Pro**, avec récupération :

- du **mot de passe généré**,
- du **userToken**,
- du **passToken**,
- et de la **version encodée en Base64**.

## 📦 Fonctionnalités

- ✅ Crée un utilisateur Nexus via l’API REST.
- 🔐 Génère un mot de passe fort.
- 🔑 Récupère le user token (outils CI).
- 🌐 Construit dynamiquement l’URL Nexus via `WORKSPACE`, `TENANT`, `DN`.

## 🧰 Prérequis

- Nexus Pro
- API REST activée
- Authentification via token admin base64
- Outils installés : `curl`, `jq`, `tr`, `base64`

## 🚀 Utilisation

```bash
export NEXUS_AUTH_B64=$(echo -n "admin:admin123" | base64)

# Optionnel : renseigner ici
export TENANT="nova"
export DN="infra.local"

./nac.sh --username ci-user
```

Si `TENANT`, `DN` ou `WORKSPACE` sont absents, ils sont demandés.

## 📂 Structure du script

- Variables à éditer en haut :
  ```bash
  TENANT=""
  WORKSPACE=""
  DN=""
  ```

- Authentification Nexus :
  ```bash
  export NEXUS_AUTH_B64=<base64(username:password)>
  ```

## 📦 Sortie affichée

```
🎉 Compte de service créé avec succès !
👤 Username        : ci-user
🔑 Password        : aZ93!qsP1!...
🔐 UserToken       : ut-123...
🗝️  PassToken       : pt-456...
📦 Base64 (auth)   : Y3UtMTIzOnB0LTQ1Ng==
```

## 💡 À venir

Ajout de commandes :
- `create-repo`
- `assign-role`
- `create-role`
